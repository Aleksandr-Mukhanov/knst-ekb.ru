<?
return array (
  'table-standart' => 'Default table',
  'big_text' => 'Big text',
  'middle_text' => 'Middle text',
  'medium' => 'Mediumiddle text selection',
  'tizer_bold_text' => 'Tizer`s caption',
  'tizer_text' => 'Tizer`s price',
);
?>