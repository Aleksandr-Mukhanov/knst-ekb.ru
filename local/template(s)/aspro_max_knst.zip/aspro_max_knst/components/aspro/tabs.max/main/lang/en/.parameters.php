<?
$MESS ['T_IBLOCK_DESC_NEWS_DATE'] = "Выводить дату элемента";
$MESS ['T_IBLOCK_DESC_NEWS_NAME'] = "Выводить название элемента";
$MESS ['T_IBLOCK_DESC_NEWS_PICTURE'] = "Выводить изображение для анонса";
$MESS ['T_IBLOCK_DESC_NEWS_TEXT'] = "Выводить текст анонса";

$MESS ['TITLE_BLOCK_NAME'] = "Заголовок блока";
$MESS ['TITLE_BLOCK_ALL_NAME'] = "Заголовок на все элементы";
$MESS ['BLOCK_NAME'] = "Лучшие предложения";
$MESS ['BLOCK_ALL_NAME'] = "Весь каталог";
$MESS ['ALL_URL_NAME'] = "Ссылка на все элементы";
$MESS ['DISPLAY_DATE'] = "Отображать дату";
$MESS ['KEY_MAP_NAME'] = "Ключ карты";
$MESS ['IMG_POSITION_NAME'] = "Положение картинки";
$MESS ['RIGHT_POS'] = "справа";
$MESS ['LEFT_POS'] = "слева";
$MESS ['NO_MARGIN_NAME'] = "Использовать отступ между блоками";
$MESS ['FILLED_NAME'] = "Заливать блоки";
$MESS ['BG_POSITION_NAME'] = "Расположение фоновой картинки";
$MESS ['TOP_LEFT'] = "сверху слева";
$MESS ['TOP_CENTER'] = "сверху по центру";
$MESS ['TOP_RIGHT'] = "сверху справа";
$MESS ['CENTER_LEFT'] = "по центру слева";
$MESS ['CENTER_CENTER'] = "по центру по центру";
$MESS ['CENTER_RIGHT'] = "по центру справа";
$MESS ['BOTTOM_LEFT'] = "снизу слева";
$MESS ['BOTTOM_CENTER'] = "снизу по центру";
$MESS ['BOTTOM_RIGHT'] = "снизу справа";

$MESS ['T_LINE_ELEMENT_COUNT'] = "Количество элементов в строке";
$MESS ['T_FAV_ITEM'] = "Свойство со стикером \"товар дня\"";
$MESS ['SHOW_ONE_CLICK_BUY_NAME'] = "Отображать кнопку \"купить в 1 клик\"";
$MESS ['SHOW_GALLERY_NAME'] = "Отображать галерею";
$MESS ['ADD_PICT_PROP_NAME'] = "Свойство с дополнительными картинками";
$MESS ['ADD_PICT_PROP_OFFER_NAME'] = "Свойство торгового предложения с дополнительными картинками";
$MESS ['ADD_DETAIL_TO_SLIDER_OFFER_NAME'] = "Добавлять детальную картинку товара к торговому предложению";
$MESS ['MAX_GALLERY_ITEMS_NAME'] = "Количество картинок в галерее";
$MESS ['SHOW_PROPS'] = "Отображать свойства";
$MESS ['DISPLAY_BOTTOM_PAGER_NAME'] = "Отображать постраничную навигацию снизу";

$MESS["STORE_USER_FIELDS"] = "Пользовательские поля наличия";
$MESS["STORE_TITLE"] = "Название";
$MESS["STORE_FIELDS"] = "Поля наличия";
$MESS["PHONE"] = "Телефон";
$MESS["SCHEDULE"] = "График работы";
$MESS["DESCRIPTION"] = "Описание";
$MESS["ADDRESS"] = "Адрес";
$MESS["EMAIL"] = "Email";
$MESS["IMAGE_ID"] = "Изображение";
$MESS["COORDINATES"] = "Координаты";
?>