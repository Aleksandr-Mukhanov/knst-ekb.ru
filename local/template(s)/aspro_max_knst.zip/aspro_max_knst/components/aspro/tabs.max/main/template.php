<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();?>

<?use \Bitrix\Main\Localization\Loc;?>
<?$frame = $this->createFrame()->begin('');?>
	<div class="content_wrapper_block"><div class="maxwidth-theme wide"></div></div>
<?$frame->end();?>