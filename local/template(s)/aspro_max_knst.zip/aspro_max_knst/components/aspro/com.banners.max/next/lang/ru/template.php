<?
$MESS['TO_CATALOG'] = 'Перейти в каталог';
?>