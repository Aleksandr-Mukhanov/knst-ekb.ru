<?
$MESS["CATALOG_TITLE"]="Путь до каталога";
?>