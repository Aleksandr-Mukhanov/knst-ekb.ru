<?
$MESS ['T_IBLOCK_DESC_NEWS_DATE'] = "Выводить дату элемента";
$MESS ['T_IBLOCK_DESC_NEWS_NAME'] = "Выводить название элемента";
$MESS ['T_IBLOCK_DESC_NEWS_PICTURE'] = "Выводить изображение для анонса";
$MESS ['T_IBLOCK_DESC_NEWS_TEXT'] = "Выводить текст анонса";

$MESS ['WIDE_NAME'] = "Широкий блок";
$MESS ['NO_MARGIN_NAME'] = "Использовать отступ между блоками";
$MESS ['BG_POSITION_NAME'] = "Расположение фоновой картинки";
$MESS ['TOP_LEFT'] = "сверху слева";
$MESS ['TOP_CENTER'] = "сверху по центру";
$MESS ['TOP_RIGHT'] = "сверху справа";
$MESS ['CENTER_LEFT'] = "по центру слева";
$MESS ['CENTER_CENTER'] = "по центру по центру";
$MESS ['CENTER_RIGHT'] = "по центру справа";
$MESS ['BOTTOM_LEFT'] = "снизу слева";
$MESS ['BOTTOM_CENTER'] = "снизу по центру";
$MESS ['BOTTOM_RIGHT'] = "снизу справа";
$MESS ['SIZE_IN_ROW_NAME'] = "Элементов в строке";

$MESS["T_SECTION_CODE"] = "Символьный код раздела";
$MESS["T_USE_TYPE_BLOCK"] = "Использовать тип блоков";
$MESS["T_SHOW_LONG_FIRST_ROW"] = "Отображать высокую первую строку с элементами";

$MESS["T_BG_BLOCK_POSITION"] = "Положение блока с картинкой";
$MESS["TOP"] = "сверху";
$MESS["BOTTOM"] = "снизу";
?>