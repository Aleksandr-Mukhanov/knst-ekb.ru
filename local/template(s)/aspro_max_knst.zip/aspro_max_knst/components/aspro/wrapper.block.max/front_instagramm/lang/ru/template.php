<?
$MESS["PREV_LINK"] = "Назад";
$MESS["MAX_LINK"] = "Вперед";
$MESS["CURRENT_PAGE"] = "Страница:";
$MESS["MORE_LINK"] = "Подробнее на Яндекс.Маркет";
$MESS ['REVIEWS_LOAD'] = "Загрузка...";
?>