<?
$MESS["IBLOCK_PRICES"] = "Цены";
$MESS["IBLOCK_TYPE"] = "Тип инфоблока";
$MESS["IBLOCK_IBLOCK"] = "Инфоблок";
$MESS["IBLOCK_PROPERTY"] = "Свойства";
$MESS["IBLOCK_SORT_ASC"] = "по возрастанию";
$MESS["IBLOCK_SORT_DESC"] = "по убыванию";
$MESS["T_LINE_ELEMENT_COUNT"] = "Количество элементов в строке";


$MESS ['T_NO_MARGIN'] = "Не использовать отступ между блоками";
$MESS ['T_WIDE_BLOCK'] = "Блок на всю ширину";
$MESS ['T_PAGE_ELEMENT_COUNT'] = "Количество отображаемых элементов";
$MESS ['T_INCLUDE_FILE'] = "Файл с дополнительным текстом";
$MESS ['T_WIDE_FIRST_BLOCK'] = "Большой первый элемент";
?>