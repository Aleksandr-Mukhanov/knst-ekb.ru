<?
$MESS["CT_BCSL_ELEMENT_DELETE_CONFIRM"] = "Будет удалена вся информация, связанная с этой записью. Продолжить?";
$MESS["COUNT_ELEMENTS_TITLE"] = "товар";
$MESS["COUNT_ELEMENTS_TITLE_2"] = "товара";
$MESS["COUNT_ELEMENTS_TITLE_3"] = "товаров";
$MESS["ALL_SECTIONS_TITLE"] = "Все";
$MESS["SHOW_ALL"] = "Показать все";
$MESS["HIDE"] = "Свернуть";
?>