<?
$MESS["CT_BCSF_FILTER_TITLE"] = "Select by:";
$MESS["CT_BCSF_FILTER_FROM"] = "From";
$MESS["CT_BCSF_FILTER_TO"] = "To";
$MESS["CT_BCSF_SET_FILTER"] = "Show";
$MESS ['CT_BCSF_SET_FILTER_TI'] = 'товар';
$MESS ['CT_BCSF_SET_FILTER_TR'] = 'товара';
$MESS ['CT_BCSF_SET_FILTER_TRM'] = 'товаров';
$MESS["CT_BCSF_DEL_FILTER"] = "Reset";
$MESS["CT_BCSF_FILTER_COUNT"] = "Selected: #ELEMENT_COUNT#";
$MESS["CT_BCSF_FILTER_SHOW"] = "Show";
$MESS["CT_BCSF_FILTER_ALL"] = "All";
$MESS['FILTER_TITLE_COMPACT'] = 'Фильтр:';
$MESS['HINT'] = 'Примечание';
$MESS['SELECTED'] = 'Выбрано: ';
?>