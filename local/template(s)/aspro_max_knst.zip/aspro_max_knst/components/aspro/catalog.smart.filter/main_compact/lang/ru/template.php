<?
$MESS ['CT_BCSF_FILTER_TITLE'] = 'Подбор параметров';
$MESS ['CT_BCSF_FILTER_FROM'] = 'От';
$MESS ['CT_BCSF_FILTER_TO'] = 'До';
$MESS ['CT_BCSF_SET_FILTER'] = 'Показать';
$MESS ['CT_BCSF_SET_FILTER_TI'] = 'товар';
$MESS ['CT_BCSF_SET_FILTER_TR'] = 'товара';
$MESS ['CT_BCSF_SET_FILTER_TRM'] = 'товаров';
$MESS ['CT_BCSF_DEL_FILTER'] = 'Очистить фильтр';
$MESS ['CT_BCSF_FILTER_COUNT'] = 'Выбрано: #ELEMENT_COUNT#';
$MESS ['CT_BCSF_FILTER_SHOW'] = 'Показать';
$MESS ['CT_BCSF_FILTER_ALL'] = 'Все';
$MESS ['PRICE'] = 'Цена';
$MESS['FILTER_TITLE_COMPACT'] = 'Фильтр:';
$MESS['FILTER_EXPAND_VALUES'] = 'Показать все';
$MESS['FILTER_HIDE_VALUES'] = 'Свернуть';
$MESS['HINT'] = 'Примечание';
$MESS['SELECTED'] = 'Выбрано: ';
$MESS['CLEAR_VALUE'] = 'Очистить';
?>