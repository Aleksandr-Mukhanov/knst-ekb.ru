<?
$MESS["CT_BCSF_FILTER_TITLE"] = "Р’РёР±С–СЂ Р·Р° РїР°СЂР°РјРµС‚СЂР°РјРё:";
$MESS["CT_BCSF_FILTER_FROM"] = "Р’С–Рґ";
$MESS["CT_BCSF_FILTER_TO"] = "Р”Рѕ";
$MESS["CT_BCSF_SET_FILTER"] = "РџРѕРєР°Р·Р°С‚Рё";
$MESS["CT_BCSF_DEL_FILTER"] = "РЎРєРёРЅСѓС‚Рё";
$MESS["CT_BCSF_FILTER_COUNT"] = "РћР±СЂР°РЅРѕ: #ELEMENT_COUNT#";
$MESS["CT_BCSF_FILTER_SHOW"] = "РџРѕРєР°Р·Р°С‚Рё";
$MESS["CT_BCSF_FILTER_ALL"] = "Р’СЃС–";
?>