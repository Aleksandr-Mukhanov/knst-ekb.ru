<?
$MESS["CP_BCT_TPL_THEME_SITE"] = "Р‘СЂР°С‚Рё С‚РµРјСѓ Р· РЅР°Р»Р°С€С‚СѓРІР°РЅСЊ СЃР°Р№С‚Сѓ (РґР»СЏ РІРёСЂС–С€РµРЅРЅСЏ bitrix.eshop)";
$MESS["CP_BCT_TPL_THEME_BLUE"] = "СЃРёРЅСЏ (С‚РµРјР° Р·Р° Р·Р°РјРѕРІС‡СѓРІР°РЅРЅСЏРј)";
$MESS["CP_BCT_TPL_THEME_GREEN"] = "Р·РµР»РµРЅР°";
$MESS["CP_BCT_TPL_THEME_WOOD"] = "РґРµСЂРµРІРѕ";
$MESS["CP_BCT_TPL_THEME_YELLOW"] = "Р¶РѕРІС‚Р°";
$MESS["CP_BCT_TPL_THEME_RED"] = "С‡РµСЂРІРѕРЅР°";
$MESS["CP_BCT_TPL_TEMPLATE_THEME"] = "РљРѕР»С–СЂРЅР° С‚РµРјР°";
$MESS["CP_BCT_TPL_THEME_BLACK"] = "С‚РµРјРЅР°";
$MESS["CP_BCT_TPL_FILTER_VIEW"] = "Р’РёРґ РІС–РґРѕР±СЂР°Р¶РµРЅРЅСЏ";
$MESS["CP_BCT_TPL_FILTER_VIEW_H"] = "РіРѕСЂРёР·РѕРЅС‚Р°Р»СЊРЅРёР№";
$MESS["CP_BCT_TPL_FILTER_VIEW_V"] = "РІРµСЂС‚РёРєР°Р»СЊРЅРёР№";
$MESS["CP_BCT_TPL_POPUP_POSITION"] = "РџРѕР·РёС†С–СЏ РґР»СЏ РІС–РґРѕР±СЂР°Р¶РµРЅРЅСЏ СЃРїР»РёРІР°СЋС‡РѕРіРѕ Р±Р»РѕРєСѓ Р· С–РЅС„РѕСЂРјР°С†С–С”СЋ РїСЂРѕ С„С–Р»СЊС‚СЂР°С†С–С—";
$MESS["CP_BCT_TPL_POPUP_POSITION_LEFT"] = "Р·Р»С–РІР°";
$MESS["CP_BCT_TPL_POPUP_POSITION_RIGHT"] = "РїСЂР°РІРѕСЂСѓС‡";
?>