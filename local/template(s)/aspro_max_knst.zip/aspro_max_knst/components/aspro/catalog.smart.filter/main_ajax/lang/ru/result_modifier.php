<?
$MESS['ASPRO_FILTER_SORT'] = 'Сортировка';
$MESS['asc'] = 'возрастание';
$MESS['desc'] = 'убывание';
?>