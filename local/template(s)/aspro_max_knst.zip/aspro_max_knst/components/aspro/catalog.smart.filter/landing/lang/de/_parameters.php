<?
$MESS["CP_BCT_TPL_THEME_SITE"] = "Farbschema der Website benutzen (fГјr bitrix.eshop)";
$MESS["CP_BCT_TPL_THEME_BLUE"] = "Blau (standardmГ¤Гџig)";
$MESS["CP_BCT_TPL_THEME_GREEN"] = "GrГјn";
$MESS["CP_BCT_TPL_THEME_WOOD"] = "Holz";
$MESS["CP_BCT_TPL_THEME_YELLOW"] = "Gelb";
$MESS["CP_BCT_TPL_THEME_RED"] = "Rot";
$MESS["CP_BCT_TPL_TEMPLATE_THEME"] = "Farbschema";
$MESS["CP_BCT_TPL_THEME_BLACK"] = "dunkel";
$MESS["CP_BCT_TPL_FILTER_VIEW"] = "Ansichtsmodus";
$MESS["CP_BCT_TPL_FILTER_VIEW_H"] = "horizontal";
$MESS["CP_BCT_TPL_FILTER_VIEW_V"] = "vertikal";
$MESS["CP_BCT_TPL_POPUP_POSITION"] = "Popup mit Filterinformationen anzeigen";
$MESS["CP_BCT_TPL_POPUP_POSITION_LEFT"] = "links";
$MESS["CP_BCT_TPL_POPUP_POSITION_RIGHT"] = "rechts";
$MESS["TP_BCSF_DISPLAY_ELEMENT_COUNT"] = "Menge anzeigen";
?>