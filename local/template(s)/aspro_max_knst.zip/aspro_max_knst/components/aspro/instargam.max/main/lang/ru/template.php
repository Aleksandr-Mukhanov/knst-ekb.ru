<?
$MESS['TITLE'] = 'Мы в Instagram';
$MESS['INSTAGRAM_ALL_ITEMS'] = 'Все записи';
?>