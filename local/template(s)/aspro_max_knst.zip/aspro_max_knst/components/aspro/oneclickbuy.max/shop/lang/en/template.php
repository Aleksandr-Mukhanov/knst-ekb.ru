<?
$MESS['CAPTION_FIO'] = 'Ваше имя';
$MESS['CAPTION_PHONE'] = 'Контактный телефон';
$MESS['CAPTION_COMMENT'] = 'Комментарий к заказу';
$MESS['CAPTION_EMAIL'] = 'E-mail';
$MESS['CAPTION_SKU_SELECT'] = 'Свойства товара';
$MESS['ORDER_LINK'] = 'Купить в 1 клик';
$MESS['FORM_HEADER_CAPTION'] = 'Купить в 1 клик';
$MESS['ORDER_BUTTON_CAPTION'] = 'Отправить';
$MESS['ERROR_USER_NAME'] = 'Обязательно укажите ваше имя';
$MESS['ERROR_EMAIL'] = 'Укажите правильный e-mail или оставьте поле пустым';
$MESS['ERROR_PHONE'] = 'Обязательно укажите контактный телефон';
$MESS['FORMAT_ERROR_PHONE'] = 'В номере телефона допускаются только цифры, скобки, пробелы, знак плюса и тире';
$MESS['FORMAT_ERROR_EMAIL'] = 'Укажите правильный e-mail или оставьте поле пустым';
$MESS['ORDER_SUCCESS'] = 'Спасибо за заказ!';
$MESS['ORDER_SUCCESS_TEXT'] = 'В ближайшее время наш менеджер свяжется с вами.';
$MESS['ORDER_ERROR'] = 'Ошибка!';
$MESS['IBLOCK_FORM_IMPORTANT'] = 'Обязательно для заполнения';
$MESS['FORM_DESCRIPTION'] = 'Вам потребуется указать только имя <br />и номер телефона. После этого наш менеджер <br />свяжется c вами для продолжения выполения заказа.';
$MESS['DELIVERY_NOTE_TITLE'] = 'Стоимость доставки'; // текст о стоимости доставки меняется в файле /bx_site/include/oneclick_delivery_text.php
$MESS['CAPTCHA_LABEL'] = 'Введите текст с картинки';
$MESS['ADD_BTN'] = 'Добавить';
$MESS['REMOVE_FILE'] = 'Отменить выбор файла';
?>
