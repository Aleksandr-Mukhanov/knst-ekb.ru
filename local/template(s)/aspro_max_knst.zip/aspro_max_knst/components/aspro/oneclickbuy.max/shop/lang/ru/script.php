<?
$MESS['NO_USER_NAME'] = "Не указано имя.";
$MESS['NO_PHONE'] = "Не указан или неправильно указан телефон.";
$MESS['NO_COMMENT'] = "Не указан комментарий к заказу.";
$MESS['BAD_EMAIL_FORMAT'] = "Указан неправильный e-mail";
$MESS['AUTH_FAIL'] = "Ошибка авторизации";
$MESS['TOO_MANY_USERS'] = "Найдено более 1 пользователя с указанным email.";
$MESS['ORDER_CREATE_FAIL'] = "Ошибка создания заказа.";
$MESS['PRODUCT_PRICE_NOT_FOUND'] = "Цена на товар не найдена.";
$MESS['ITEM_ADD_FAIL'] = "Ошибка добавления товара в заказ.";
$MESS['ORDER_CREATE_SUCCESS'] = "Заказ успешно оформлен.";
$MESS['PHONE'] = "Телефон для связи: ";
$MESS['EMPTY_BASKET'] = '<i id="cart-status"><a href="/personal/cart/">Ваша корзина пуста</a>';
?>
