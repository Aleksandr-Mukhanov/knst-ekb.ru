<?
$MESS["CT_BNL_ELEMENT_DELETE_CONFIRM"] = "Будет удалена вся информация, связанная с этой записью. Продолжить?";
$MESS["CITY_TITLE"] = "Ваш город";
$MESS["CITY_PLACEHOLDER"] = "Введите название города";
$MESS["OKRUG"] = "Округ";
$MESS["REGION"] = "Область, республика, край";
$MESS["CITY"] = "Город";
$MESS["CITY_YES"] = "Да, все верно";
$MESS["CITY_CHANGE"] = "Выбрать другой";
?>