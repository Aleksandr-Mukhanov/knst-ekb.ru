<?
$MESS["CITY_TITLE"] = "Ваш город";
$MESS["CITY_PLACEHOLDER"] = "Введите название города";
$MESS["EXAMPLE_CITY"] = "Например:";
$MESS["OKRUG"] = "Округ";
$MESS["REGION"] = "Регион";
$MESS["CITY"] = "Город";
$MESS["CITY_YES"] = "Да, все верно";
$MESS["CITY_CHANGE"] = "Выбрать другой";
?>