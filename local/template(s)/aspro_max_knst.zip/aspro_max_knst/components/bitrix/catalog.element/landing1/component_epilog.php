<?
if (isset($arResult['SECTION_BNR_CONTENT']) && $arResult['SECTION_BNR_CONTENT'] == true)
{
	global $SECTION_BNR_CONTENT;
	$SECTION_BNR_CONTENT = true;
}
?>