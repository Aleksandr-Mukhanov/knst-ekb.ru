<?
	$MESS["SECT_ORDER_desc"] = " (decrease)";
	$MESS["SECT_ORDER_asc"] = " (increase)";
	$MESS["SECT_SORT_SORT"] = "By sort index";
	$MESS["SECT_SORT_SHOWS"] = "By popularity";
	$MESS["SECT_SORT_NAME"] = "Alphabetically";
	$MESS["SECT_SORT_PRICE"] = "By price";
	$MESS["SECT_SORT_QUANTITY"] = "In stock";
	$MESS["SECT_SORT_CATALOG_AVAILABLE"] = "In stock";
	$MESS["SECT_DISPLAY_LIST"] = "list";
	$MESS["SECT_DISPLAY_TABLE"] = "table";
	$MESS["SECT_DISPLAY_BLOCK"] = "tiles";
	$MESS["SECT_DISPLAY_3"] = "Small list";
	$MESS["SECT_DISPLAY_4"] = "Big list";
	$MESS["CATALOG_SMART_FILTER_TITLE"] = "Filter";
	$MESS["CATALOG_DROP_TO"] = "Show by:";
	$MESS["CATALOG_IN_CART"] = "In the basket";
	$MESS["TITLE_QUANTITY"] = "pc.";
	$MESS["UNTIL_AKC"] = "Until the end of the promotion";
	$MESS["TITLE_QUANTITY_BLOCK"] = "balance";
	$MESS["CATALOG_ECONOMY"] = "Saving";
	$MESS["ADD_ERROR_COMPARE"] = "Error adding product to comparison list";
	$MESS["ADD_ERROR_BASKET"] = "Error adding item to cart";
	$MESS["RESET_FILTERS"] = "Clear all filters";
	$MESS["VIEWED_TITLE"] = "Previously you viewed";
	$MESS["BEST_TITLE"] = "Best deals";
	$MESS["TAB_BLOG_NAME"] = "Articles";

	$MESS['S_ASK_QUESTION'] = 'Ask a Question';
	$MESS['S_ORDER_SERVISE'] = 'Order service';
	$MESS['POPULAR_CATEGORYS'] = 'Popular Categories';
	$MESS['T_NEWS_NEWS_NA'] = 'Section not found';
	$MESS['NOTHING_SELECTED'] = 'Nothing selected';

	$MESS["SORT_TITLE_PROPETY"] = "#CODE#";
	$MESS["SECT_SORT_CUSTOM"] = "default";
?>