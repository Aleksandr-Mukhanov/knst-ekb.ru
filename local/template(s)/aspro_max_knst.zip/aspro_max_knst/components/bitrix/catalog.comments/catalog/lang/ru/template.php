<?
$MESS["IBLOCK_CSC_TAB_COMMENTS"] = "Отзывы";
$MESS["IBLOCK_CSC_TAB_VK"] = "Вконтакте";
$MESS["IBLOCK_CSC_NO_DATA"] = "В настройках компонента не выбран ни один тип комментариев";
$MESS["IBLOCK_CSC_COMMENTS_LOADING"] = "Загрузка отзывов...";
$MESS["INPUT_FILE_DEFAULT"] = "Прикрепить изображение (не более ".$_SESSION['BLOG_MAX_IMAGE_SIZE']." мб)";
$MESS["EMPTY_REVIEWS"] = "Помогите другим пользователям с выбором - будьте первым, кто поделится своим мнением об этом товаре";
?>