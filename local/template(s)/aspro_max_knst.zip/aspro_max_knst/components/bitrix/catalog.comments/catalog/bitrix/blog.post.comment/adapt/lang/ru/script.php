<?
$MESS ['BPC_TEXT_ENTER_URL'] = "Введите полный адрес (URL)";
$MESS ['BPC_TEXT_ENTER_URL_NAME'] = "Введите название сайта";
$MESS ['BPC_TEXT_ENTER_IMAGE'] = "Введите полный адрес (URL) изображения";
$MESS ['BPC_LIST_PROMPT'] = "Введите пункт списка. Нажмите 'Отмена' или оставьте пробел для завершения списка";
$MESS ['BPC_ERROR_NO_URL'] = "Вы должны ввести адрес (URL)";
$MESS ['BPC_ERROR_NO_TITLE'] = "Вы должны ввести название";
$MESS ['BPC_ERROR_NO_COMMENT_PERM'] = "Не достаточно прав для комментирования";
?>