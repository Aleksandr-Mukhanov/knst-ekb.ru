<?
$MESS["CP_BCC_TPL_THEME_SITE"] = "Брати тему з налаштувань сайту (для вирішення bitrix.eshop)";
$MESS["CP_BCC_TPL_THEME_BLUE"] = "синя (тема за замовчуванням)";
$MESS["CP_BCC_TPL_THEME_GREEN"] = "Зелена";
$MESS["CP_BCC_TPL_THEME_RED"] = "Червона";
$MESS["CP_BCC_TPL_THEME_WOOD"] = "Дерево";
$MESS["CP_BCC_TPL_THEME_YELLOW"] = "Жовта";
$MESS["CP_BCC_TPL_THEME_BLACK"] = "Темна";
$MESS["CP_BCC_TPL_TEMPLATE_THEME"] = "Колірна тема";
?>