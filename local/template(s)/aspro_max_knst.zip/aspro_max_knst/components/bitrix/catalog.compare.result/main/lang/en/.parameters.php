<?
$MESS["CP_BCC_TPL_THEME_SITE"] = "Use site theme (for bitrix.eshop)";
$MESS["CP_BCC_TPL_THEME_BLUE"] = "blue (default theme)";
$MESS["CP_BCC_TPL_THEME_GREEN"] = "green";
$MESS["CP_BCC_TPL_THEME_RED"] = "red";
$MESS["CP_BCC_TPL_THEME_WOOD"] = "wood";
$MESS["CP_BCC_TPL_THEME_YELLOW"] = "yellow";
$MESS["CP_BCC_TPL_THEME_BLACK"] = "dark";
$MESS["CP_BCC_TPL_TEMPLATE_THEME"] = "Color theme";
?>