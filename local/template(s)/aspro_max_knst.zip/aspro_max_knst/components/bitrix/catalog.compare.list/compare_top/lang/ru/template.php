<?
$MESS ['CATALOG_COMPARE_ELEMENTS'] = "Сравнение";
$MESS ['CATALOG_COMPARE_ELEMENTS_ALL'] = "Список сравниваемых элементов";
$MESS ['CATALOG_COMPARE_ELEMENTS_COUNT'] = "пусто";
?>