<?
$MESS["CVP_TPL_MESS_RCM"] = "Персональные рекомендации:";
$MESS["CVP_TPL_ELEMENT_DELETE_CONFIRM"] = "Будет удалена вся информация, связанная с этой записью. Продолжить?";
$MESS["CVP_TPL_MESS_BTN_BUY"] = "Купить";
$MESS["CVP_TPL_MESS_BTN_ADD_TO_BASKET"] = "В корзину";
$MESS["CVP_TPL_MESS_PRODUCT_NOT_AVAILABLE"] = "Нет в наличии";
$MESS["CVP_TPL_MESS_BTN_DETAIL"] = "Подробнее";
$MESS["CVP_TPL_MESS_BTN_SUBSCRIBE"] = "Подписаться";
$MESS["CVP_CATALOG_SET_BUTTON_BUY"] = "Перейти в корзину";
$MESS["CVP_ADD_TO_BASKET_OK"] = "Товар добавлен в корзину";
$MESS["CVP_TPL_MESS_PRICE_SIMPLE_MODE"] = "от #PRICE# за #MEASURE#";
$MESS["CVP_TPL_MESS_MEASURE_SIMPLE_MODE"] = "#VALUE# #UNIT#";
$MESS["CVP_TPL_MESS_BTN_COMPARE"] = "Сравнить";
$MESS["CVP_CATALOG_TITLE_ERROR"] = "Ошибка";
$MESS["CVP_CATALOG_TITLE_BASKET_PROPS"] = "Свойства товара, добавляемые в корзину";
$MESS["CVP_CATALOG_BASKET_UNKNOWN_ERROR"] = "Неизвестная ошибка при добавлении товара в корзину";
$MESS["CVP_CATALOG_BTN_MESSAGE_CLOSE"] = "Закрыть";
$MESS["CVP_CATALOG_BTN_MESSAGE_BASKET_REDIRECT"] = "Перейти в корзину";
$MESS["CVP_CATALOG_BTN_MESSAGE_SEND_PROPS"] = "Выбрать";
$MESS["CVP_MSG_YOU_HAVE_NOT_YET"] = "Вы еще не просмотрели ни один товар.";
$MESS["CATALOG_ECONOMY"] = "Экономия";
$MESS["CATALOG_WISH"] = "Отложить";
$MESS["CATALOG_WISH_OUT"] = "В отложенных";
$MESS["CATALOG_COMPARE"] = "Сравнить";
$MESS["CATALOG_COMPARE_OUT"] = "В сравнении";
$MESS["CATALOG_FROM"] = "от";
?>