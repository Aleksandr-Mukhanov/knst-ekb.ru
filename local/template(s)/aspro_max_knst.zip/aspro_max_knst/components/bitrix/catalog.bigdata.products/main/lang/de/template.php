<?
$MESS["CVP_TPL_MESS_RCM"] = "PersГ¶nliche Empfehlungen:";
$MESS["CVP_TPL_ELEMENT_DELETE_CONFIRM"] = "Alle Informationen, die mit diesem Eintrag verbunden sind, werden gelГ¶scht. Fortfahren?";
$MESS["CVP_TPL_MESS_BTN_BUY"] = "Kaufen";
$MESS["CVP_TPL_MESS_BTN_ADD_TO_BASKET"] = "In den Warenkorb";
$MESS["CVP_TPL_MESS_PRODUCT_NOT_AVAILABLE"] = "Nicht verfГјgbar";
$MESS["CVP_TPL_MESS_BTN_DETAIL"] = "Details";
$MESS["CVP_TPL_MESS_BTN_SUBSCRIBE"] = "Abonnieren";
$MESS["CVP_CATALOG_SET_BUTTON_BUY"] = "Warenkorb anzeigen";
$MESS["CVP_ADD_TO_BASKET_OK"] = "Das Produkt wurde zum Warenkorb hinzugefГјgt";
$MESS["CVP_TPL_MESS_PRICE_SIMPLE_MODE"] = "ab #PRICE# fГјr #MEASURE#";
$MESS["CVP_TPL_MESS_MEASURE_SIMPLE_MODE"] = "#VALUE# #UNIT#";
$MESS["CVP_TPL_MESS_BTN_COMPARE"] = "Vergleichen";
$MESS["CVP_CATALOG_TITLE_ERROR"] = "Fehler";
$MESS["CVP_CATALOG_TITLE_BASKET_PROPS"] = "Produkteigenschaften, die zum Warenkorb hinzugefГјgt werden";
$MESS["CVP_CATALOG_BASKET_UNKNOWN_ERROR"] = "Unbekannter Fehler beim HinzufГјgen des Produktes zum Warenkorb";
$MESS["CVP_CATALOG_BTN_MESSAGE_CLOSE"] = "SchlieГџen";
$MESS["CVP_CATALOG_BTN_MESSAGE_BASKET_REDIRECT"] = "Warenkorb anzeigen";
$MESS["CVP_CATALOG_BTN_MESSAGE_SEND_PROPS"] = "AuswГ¤hlen";
$MESS["CVP_MSG_YOU_HAVE_NOT_YET"] = "Sie haben sich kein einziges Produkt angesehen.";
?>