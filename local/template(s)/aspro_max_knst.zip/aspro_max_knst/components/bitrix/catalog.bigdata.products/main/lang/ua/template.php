<?
$MESS["CVP_TPL_MESS_RCM"] = "Персональні рекомендації:";
$MESS["CVP_TPL_ELEMENT_DELETE_CONFIRM"] = "Буде видалена вся інформація, пов'язана з цим записом. Продовжити?";
$MESS["CVP_TPL_MESS_BTN_BUY"] = "Купити";
$MESS["CVP_TPL_MESS_BTN_ADD_TO_BASKET"] = "До кошику";
$MESS["CVP_TPL_MESS_PRODUCT_NOT_AVAILABLE"] = "Товар наявності";
$MESS["CVP_TPL_MESS_BTN_DETAIL"] = "Детальніше";
$MESS["CVP_TPL_MESS_BTN_SUBSCRIBE"] = "Підписатися";
$MESS["CVP_CATALOG_SET_BUTTON_BUY"] = "Перейти до кошику";
$MESS["CVP_ADD_TO_BASKET_OK"] = "Товар доданий до кошику";
$MESS["CVP_TPL_MESS_PRICE_SIMPLE_MODE"] = "від #PRICE# за #MEASURE#";
$MESS["CVP_TPL_MESS_MEASURE_SIMPLE_MODE"] = "#VALUE# #UNIT#";
$MESS["CVP_TPL_MESS_BTN_COMPARE"] = "Порівняти";
$MESS["CVP_CATALOG_TITLE_ERROR"] = "Помилка";
$MESS["CVP_CATALOG_TITLE_BASKET_PROPS"] = "Властивості товару, що додаються в кошик";
$MESS["CVP_CATALOG_BASKET_UNKNOWN_ERROR"] = "Невідома помилка при додаванні товару в кошик";
$MESS["CVP_CATALOG_BTN_MESSAGE_CLOSE"] = "Закрити";
$MESS["CVP_CATALOG_BTN_MESSAGE_BASKET_REDIRECT"] = "Перейти до кошику";
$MESS["CVP_CATALOG_BTN_MESSAGE_SEND_PROPS"] = "Вибрати";
$MESS["CVP_MSG_YOU_HAVE_NOT_YET"] = "Ви ще не переглянули жоден товар.";
?>