<?php
$MESS['CVP_LINE_ELEMENT_COUNT'] = "Количество элементов, выводимых в одной строке";
$MESS['LINE_ELEMENT_COUNT_TIP'] = "Количество элементов, выводимых в строке может быть от 1 до 5";
$MESS["CVP_TPL_THEME_BLUE"] = "синяя (тема по умолчанию)";
$MESS["CVP_TPL_THEME_GREEN"] = "зеленая";
$MESS["CVP_TPL_THEME_RED"] = "красная";
$MESS["CVP_TPL_THEME_WOOD"] = "дерево";
$MESS["CVP_TPL_THEME_YELLOW"] = "желтая";
$MESS["CVP_TPL_THEME_BLACK"] = "темная";
$MESS["CVP_TPL_TEMPLATE_THEME"] = "Цветовая тема";
$MESS["CVP_TPL_THEME_SITE"] = "Брать тему из настроек сайта (для решения bitrix.eshop)";
?>