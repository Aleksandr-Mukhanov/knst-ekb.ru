<?
CJSCore::Init(array("popup"));
?>