<? if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();

use \Bitrix\Main\Localization\Loc;

/**
 * @global CMain $APPLICATION
 * @var array $arParams
 * @var array $arResult
 * @var CatalogSectionComponent $component
 * @var CBitrixComponentTemplate $this
 * @var string $templateName
 * @var string $componentPath
 *
 *  _________________________________________________________________________
 * |	Attention!
 * |	The following comments are for system use
 * |	and are required for the component to work correctly in ajax mode:
 * |	<!-- items-container -->
 * |	<!-- pagination-container -->
 * |	<!-- component-end -->
 */

$this->setFrameMode(true);
?>

<section class="popular">
    <div class="wrap">
        <h3>Популярные товары</h3>

        <div class="popular__inner">
            <div class="products">
                <div class="products__inner">
                    <? foreach ($arResult['ITEMS'] as $arItem): ?>
                        <?
                            $arPrice = current($arItem['PRICES']);
                            $img = CFile::ResizeImageGet($arItem['PREVIEW_PICTURE']['ID'], array('width'=>190, 'height'=>190), BX_RESIZE_IMAGE_PROPORTIONAL, true);
                        ?>
                        <div class="product">
                            <div class="product__image">
                                <a href="<?=$arItem['DETAIL_PAGE_URL'];?>">
                                    <img src="<?=$img['src'];?>" alt="">
                                </a>
                            </div>
                            <div class="product__price"><strong>Цена:</strong> <?=$arPrice['PRINT_VALUE'];?></div>
                            <div class="product__title">
                                <a href="<?=$arItem['DETAIL_PAGE_URL'];?>"><?=$arItem['NAME'];?></a>
                            </div>
                            <div class="button"><a href="javascript:void(0);" class="btn btn-sm add2basket" data-id="<?=$arItem['ID'];?>">в корзину</a></div>
                        </div>
                    <? endforeach; ?>
                </div>
            </div>

            <div class="popular-form form">
                <form>
                    <div class="popular-form__head">
                        <div class="popular-form__title">Отправьте нам ваш список,<br> а мы все подсчитаем</div>
                        <div class="popular-form__file">
                            <label class="form__file">
                                <i class="icon" data-svg="<?=SITE_TEMPLATE_PATH;?>/images/svg/file-lg.svg"></i>
                                <input type="file" id="file">
                                <span>Прикрепить файл</span>
                            </label>
                        </div>
                    </div>

                    <div class="popular-form__body">
                        <div class="form__row">
                            <input type="text" class="inputbox" placeholder="Имя">
                        </div>
                        <div class="form__row">
                            <input type="tel" class="inputbox" placeholder="Телефон">
                        </div>
                        <div class="form__row form__submit">
                            <input type="submit" class="btn" value="рассчитать">
                        </div>
                        <div class="form__row form__accept"><i data-svg="<?=SITE_TEMPLATE_PATH;?>/images/svg/icons/check.svg"></i><span>Согласен с <a href="#">политикой конфиденциальности</a> и <a href="#">пользовательским соглашением</a></span>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>
