<?
$MESS["CPT_BCSL_VIEW_MODE_LINE"] = "List";
$MESS["CPT_BCSL_VIEW_MODE_TEXT"] = "Text";
$MESS["CPT_BCSL_VIEW_MODE_TILE"] = "Tile";
$MESS["CPT_BCSL_VIEW_MODE"] = "Subsections view mode";
$MESS["CPT_BCSL_SHOW_PARENT_NAME"] = "Show section name";
$MESS["SHOW_PARENT_NAME_TIP"] = "Specifies to show the name of a current section (except for the root section).";
$MESS["CPT_BCSL_VIEW_MODE_LIST"] = "Multilevel list ";
$MESS["CPT_BCSL_HIDE_SECTION_NAME"] = "Hide subsection names";
$MESS["VIEW_MODE_TIP"] = "Specifies the way the subsections are laid out on a page. Attention! Only the \"Multilevel list\" option may specify an arbitrary count of subsections. For all other view modes, the subsection nesting depth must be 1.";
$MESS["HIDE_SECTION_NAME_TIP"] = "If selected, the \"Tile\" view mode will show only the section images.";
?>