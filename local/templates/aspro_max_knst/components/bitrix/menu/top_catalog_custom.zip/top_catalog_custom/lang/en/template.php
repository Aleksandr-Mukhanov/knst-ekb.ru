<?
$MESS['S_MORE_ITEMS'] = "Ещё";
$MESS['CT_BST_SEARCH_BUTTON'] = "Найти";
?>