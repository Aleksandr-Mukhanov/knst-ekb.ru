<?
$MESS["CMP_TITLE"] = "Поиск";
$MESS["SECT_SORT_SHOWS"] = "По популярности";
$MESS["SECT_SORT_NAME"] = "По алфавиту";
$MESS["SECT_SORT_PRICE"] = "По цене";
$MESS["SECT_SORT_QUANTITY"] = "По наличию";
$MESS["SECT_SORT_CATALOG_AVAILABLE"] = "По наличию";
$MESS["SECT_DISPLAY_LIST"] = "списком";
$MESS["SECT_DISPLAY_TABLE"] = "таблицей";
$MESS["SECT_DISPLAY_BLOCK"] = "плиткой";
$MESS["CATALOG_SMART_FILTER_TITLE"] = "Фильтр";
$MESS["CATALOG_DROP_TO"] = "Показывать по:";
$MESS["CATALOG_IN_CART"] = "В корзине";
$MESS["TITLE_QUANTITY"] = "штук";
$MESS["UNTIL_AKC"] = "До конца акции";
$MESS["TITLE_QUANTITY_BLOCK"] = "Остаток";
$MESS["CATALOG_ECONOMY"] = "Экономия";
$MESS["ADD_ERROR_COMPARE"] = "Ошибка добавления товара в список сравнения";
$MESS["ADD_ERROR_BASKET"] = "Ошибка добавления товара в корзину";
$MESS["RESET_FILTERS"] = "Сбросить все фильтры";
$MESS['S_ASK_QUESTION'] = 'Задать вопрос';
?>