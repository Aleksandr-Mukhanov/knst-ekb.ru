<?
	$MESS["SECT_SORT_POPULARITY"] = "По популярности";
	$MESS["SECT_SORT_NAME"] = "По алфавиту";
	$MESS["SECT_SORT_PRICE"] = "По цене";
	$MESS["SECT_DISPLAY_LIST"] = "Списком";
	$MESS["SECT_DISPLAY_TABLE"] = "Таблицей";
	$MESS["CATALOG_DROP_TO"] = "выводить по";
	$MESS["CATALOG_IN_CART"] = "В корзине";
	$MESS["VIEWED_TITLE"] = "Ранее вы смотрели";
	$MESS["BEST_TITLE"] = "Лучшие предложения";
?>