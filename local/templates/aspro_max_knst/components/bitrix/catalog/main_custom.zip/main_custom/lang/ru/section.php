<?
    $MESS["SECT_SORT_TITLE"] = "Сортировать по:";
	$MESS["SECT_ORDER_desc"] = " (дорогие)";
	$MESS["SECT_ORDER_asc"] = " (дешевые)";
	$MESS["SECT_SORT_SORT"] = "По индексу сортировки";
	$MESS["SECT_SORT_SHOWS"] = "По популярности";
	$MESS["SECT_SORT_NAME"] = "По алфавиту";
	$MESS["SECT_SORT_PRICE"] = "Цена";
	$MESS["SECT_SORT_QUANTITY"] = "По наличию";
	$MESS["SECT_SORT_CATALOG_AVAILABLE"] = "По наличию";
	$MESS["SECT_DISPLAY_LIST"] = "списком";
	$MESS["SECT_DISPLAY_TABLE"] = "таблицей";
	$MESS["SECT_DISPLAY_BLOCK"] = "плиткой";
	$MESS["SECT_DISPLAY_3"] = "Маленький список";
	$MESS["SECT_DISPLAY_4"] = "Большой список";
	$MESS["CATALOG_SMART_FILTER_TITLE"] = "Фильтр";
	$MESS["CATALOG_DROP_TO"] = "Показывать по:";
	$MESS["CATALOG_IN_CART"] = "В корзине";
	$MESS["TITLE_QUANTITY"] = "шт.";
	$MESS["UNTIL_AKC"] = "До конца акции";
	$MESS["TITLE_QUANTITY_BLOCK"] = "Остаток";
	$MESS["CATALOG_ECONOMY"] = "Экономия";
	$MESS["ADD_ERROR_COMPARE"] = "Ошибка добавления товара в список сравнения";
	$MESS["ADD_ERROR_BASKET"] = "Ошибка добавления товара в корзину";
	$MESS["RESET_FILTERS"] = "Сбросить все фильтры";
	$MESS["VIEWED_TITLE"] = "Ранее вы смотрели";
	$MESS["BEST_TITLE"] = "Лучшие предложения";
	$MESS["TAB_BLOG_NAME"] = "Статьи";

	$MESS['S_ASK_QUESTION'] = 'Задать вопрос';
	$MESS['S_ORDER_SERVISE'] = 'Заказать услугу';
	$MESS['POPULAR_CATEGORYS'] = 'Популярные категории';
	$MESS['T_NEWS_NEWS_NA'] = 'Раздел не найден';
	$MESS['NOTHING_SELECTED'] = 'Ничего не выбрано';

	$MESS["SORT_TITLE_PROPETY"] = "#CODE#";
	$MESS["SECT_SORT_CUSTOM"] = "По умолчанию";
?>