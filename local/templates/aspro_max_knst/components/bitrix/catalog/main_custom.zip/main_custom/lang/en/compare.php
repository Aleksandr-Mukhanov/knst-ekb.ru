<?
	$MESS ['CATALOG_COMPARE_HEADER_TITLE'] = "Сравнение товаров";
	$MESS["CATALOG_IN_CART"] = "В корзине";
?>